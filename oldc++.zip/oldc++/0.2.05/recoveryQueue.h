#pragma once

namespace Odin
{

class RecoveryQueue
{
	public:
		explicit RecoveryQueue(int a_layer);
};

/*
class RecoveryQueue {
	private:
	int counter;
	int lastelement;
	int lastInsertedElement;
	int stepLastElement;
	int layer;
	vector <Neuron*> queue[queueMax];
	public:
	Neuron *lastType2Neuron;
	RecoveryQueue(void) {}
	RecoveryQueue (int);
	int deletePattern(Neuron *,  unsigned int, unsigned int);
	void insert(Neuron *);
	void checkNewPattern ();
	void recover(void);
	bool noChangeInCycle(void);
	int countItems (void);
};

*/

} //Odin
