#include <cassert>
#include "neuron.h"
#include "ICallbacks.h"
#include "sense.h"

namespace Odin
{

Sense::Sense(ICallbacks& a_callbacks, const Sense::Parameters& a_parameters) :
	m_params(a_parameters),
	m_aQueue(),
	m_callbacks(a_callbacks)
{
	//first check that the capacity of recQueue is sufficient
	//	(*recQueueTemp).reserve((*recQueueTemp).size()+3);
	//	aqueue = queue;

	p_createInitialNeurons();
}

~Sense::Sense()
{
	size_t i = 0;
	for (; i < m_inputNeurons.size(); ++i) {
		if (m_inputNeurons[i]) delete m_inputNeurons[i];
	}
	for (i=0; i < m_outputNeurons.size(); ++i) {
		if (m_outputNeurons[i]) delete m_outputNeurons[i];
	}
}

void Sense::input(TInputType c)
{
	assert(c < m_inputNeurons.size());
	assert(c < m_outputNeurons.size());

	outputNeurons[c]->lastfired = m_stepCounter;
	//aqueue->schedActivation( inputNeurons[c]->dendrites[0],0);
	inputNeurons[c]->dendrites[0]->stimulate();
	//inputNeurons[c]->checkActivation();
}

void Sense::p_createInitialNeurons()
{
	/*
	inputNeurons[i] = new  Neuron (aqueue,recQueueTemp,0,0);
			 outputNeurons[i] = new  Neuron (aqueue,recQueueTemp,0,0);

			 inputNeurons[i]->dendrites.push_back(new Dendrite(1));
			 inputNeurons[i]->dendrites[0]->dendriteTo = inputNeurons[i];
			 inputNeurons[i]->dendrites[0]->dendriteFrom = outputNeurons[i];
			 inputNeurons[i]->dendrites[0]->synapses = 1;
			 //inputNeurons[i]->axons.push_back(new Dendrite());
			 //inputNeurons[i]->axons[0]->dendriteTo = outputNeurons[i];
			 //inputNeurons[i]->axons[0]->dendriteFrom = inputNeurons[i];
			 //inputNeurons[i]->axons[0]->synapses = 1;
			 //outputNeurons[i]->axons.resize(1);
			 //outputNeurons[i]->axons[0].push_back(new Dendrite());
			 //outputNeurons[i]->axons[0][0]->dendriteFrom = outputNeurons[i];
			 //outputNeurons[i]->axons[0][0]->dendriteTo = inputNeurons[i];
			 //outputNeurons[i]->axons[0][0]->synapses = 1;
			 //outputNeurons[i]->axons[0][0]->self=0;
			 outputNeurons[i]->dendrites.push_back(new Dendrite());
			 outputNeurons[i]->dendrites[0]->dendriteTo = outputNeurons[i];
			 outputNeurons[i]->dendrites[0]->synapses = 1;
			 outputNeurons[i]->dendrites[0]->activationDelay = 0;

			 //outputNeurons[i]->dendrites[1]->inhibitory = true;

			 AnsiString captionID = char(i);
			 outputNeurons[i]->outputData = char(i);
			 captionID +=  " (" +  inputNeurons[i]->id + ")";
			 inputNeurons[i]->debugCallingNode = SDIAppForm->addLink(captionID);
			// *inputNeurons = new Neuron (queue);
	*/


}

void Sense::p_activateQueue()
{
	//moved from ActivationQueue::activate()
	/*
	stepCounter++;
	for (unsigned int n=0;n<recQueue.size();n++ ) {
				recQueue[n].recover();
	}
	Debug1->ListBox1->Items->Insert(0,AnsiString("----------- ") + AnsiString(stepCounter) + AnsiString("------------"));
	*/
	
	++m_stepCounter;
	for (size_t i = 0; i< m_recQueue.size(); ++i) {
		m_recQueues[i].recover();
	}
	m_callbacks.stepCounterCallback(m_stepCounter);
	m_actQueue.activate();
}

} //Odin
