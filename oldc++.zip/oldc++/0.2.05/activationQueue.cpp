#include <cassert>
#include "sense.h"
#include "dendrite.h"
#include "activationQueue.h"

namespace Odin
{

void ActivationQueue::schedActivation(
	Dendrite* a_dendrite, int a_delay, double a_actVal
)
{
	assert(a_dendrite);
	m_queue.push(Item(*a_dendrite, a_actVal, a_delay + m_sense.getStepCounter()));
}

void ActivationQueue::activate()
{
	TQueue qtemp;

	int stepCounter = m_sense.getStepCounter();
	double minActivation = m_sense.getMinActivation();

	//first activate subsequent neurons
	while (!m_queue.empty() && m_queue.top().pos <= stepCounter) {
		Dendrite& d = m_queue.top().dendrite;
		double actVal = 0.0;
		//int cs = d->dendriteTo->countSynapses();
		//if (cs > 0) actVal = d->synapses / double(d->dendriteTo->countSynapses());
		//else actVal = 0;
		actVal = m_queue.top().actVal;
		//actVal = 1;
		if (actVal > minActivation && d.dendriteTo->lastfired < (stepCounter-recoveryTime)) {
			d.dendriteTo->activate(actVal);
			qtemp.push(Item(d, d->dendriteTo->activationVal,0));
		}
		m_queue.pop();
	}
	//now check if the activation leads to depolarization of the subsequent neuron
	while (!qtemp.empty()) {
		Dendrite& d = qtemp.top().dendrite;

		if (d.dendriteTo->checkActivation() == 1) {
			//d->synapses += 2; //hebbian learning rule - synaptic plasticity
		}
        d->synapses += 1; //hebbian learning rule - synaptic plasticity
		qtemp.pop();
	}
}

/*
void ActivationQueue::schedActivation (Dendrite* dendrite, int aDelay) {
		this->q.push(Aqueue(aDelay+stepCounter,dendrite,1));
}

void ActivationQueue::schedActivation (Dendrite* dendrite, int aDelay, double aVal) {
		this->q.push(Aqueue(aDelay+stepCounter,dendrite,aVal));
}

void ActivationQueue::activate (void) {
	stepCounter++;
	for (unsigned int n=0;n<recQueue.size();n++ ) {
				recQueue[n].recover();
	}
	Debug1->ListBox1->Items->Insert(0,AnsiString("----------- ") + AnsiString(stepCounter) + AnsiString("------------"));
	priority_queue <Aqueue> qtemp;
	//first activate subsequent neurons
	while ((!this->q.empty()) && this->q.top().getPos() <= stepCounter) {
		Dendrite *d;
		d = this->q.top().getDendrite();
		double actVal = 0;
		//int cs = d->dendriteTo->countSynapses();
		//if (cs > 0) actVal = d->synapses / double(d->dendriteTo->countSynapses());
		//else actVal = 0;
		actVal = this->q.top().getAct();
		//actVal = 1;
		if (actVal > minActivation) {
		if (d->dendriteTo->lastfired < (stepCounter - recoveryTime)) {
			d->dendriteTo->activate(actVal);
			qtemp.push(Aqueue(d->dendriteTo->activationVal,d));
		}}
		this->q.pop();
	}
	//now check if the activation leads to depolarization of the subsequent neuron
	while (!qtemp.empty()) {
		Dendrite *d;
		d = qtemp.top().getDendrite();

		if (d->dendriteTo->checkActivation() == 1) {
			//d->synapses += 2; //hebbian learning rule - synaptic plasticity
		}
        d->synapses += 1; //hebbian learning rule - synaptic plasticity
		qtemp.pop();
	}
}

bool ActivationQueue::isEmpty(void) {
    return this->q.empty();
}

*/

} //Odin
