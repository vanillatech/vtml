#pragma once
#include <vector>
#include "recoveryQueue.h"
#include "activationQueue.h"
#include "config.h"

namespace Odin
{

class Neuron;
class ICallbacks;

class Sense
{
	public:
		struct Parameters
		{
			int queueMax;
			int recoveryTime;
			int blockTime;
			float activationBias;
			float drain;
			float minActivation;
			float fireMargin;
			float learnRate;
			//~etc

			Parameters() :
				queueMax(QUEUE_MAX),
				recoveryTime(RECOVERY_TIME),
				blockTime(BLOCK_TIME),
				activationBias(ACTIVATION_BIAS),
				drain(DRAIN),
				minActivation(MIN_ACTIVATION),
				fireMargin(FIRE_MARGIN),
				learnRate(LEARN_RATE)
			{}
		};

		explicit Sense(ICallbacks& a_callbacks, const Parameters& a_parameters = Parameters());
		~Sense();

		void input(TInputType c);
		
		int getStepCounter() {
			return m_stepCounter;
		}

		int getRecQueueIdle() {
			return m_recQueueIdle;
		}

		double getMinActivation() {
			return m_params.minActivation;
		}
		
	private:
		void p_createInitialNeurons();
		void p_activateQueue();

		Parameters m_params;
		std::vector<Neuron*> m_inputNeurons;
		std::vector<Neuron*> m_outputNeurons;
		ActivationQueue m_actQueue;
		std::vector<RecoveryQueue> m_recQueues;
		ICallbacks& m_callbacks;
		int m_neuronCounter;
		int m_stepCounter;
		int m_recQueueIdle;

		// No copying so far.
		Sense(const Sense&);
		Sense& operator=(const Sense&);
};

/*

class ActivationQueue;
class Neuron;


class Sense {
	private:
	ActivationQueue *aqueue;
	Neuron *inputNeurons[256];
	Neuron *outputNeurons[256];
	public:
	Sense (ActivationQueue *queue, vector< RecoveryQueue > *recQueueTemp) {
		//inputNeurons = new (Neuron*)[256];
		//inputNeurons = new Neuron(&queue)[256];
		//first check that the capacity of recQueue is sufficient
		(*recQueueTemp).reserve((*recQueueTemp).size()+3);
		aqueue = queue;
		for ( int  i = 0 ; i < 256 ; i++ ) {
			 inputNeurons[i] = new  Neuron (aqueue,recQueueTemp,0,0);
			 outputNeurons[i] = new  Neuron (aqueue,recQueueTemp,0,0);

			 inputNeurons[i]->dendrites.push_back(new Dendrite(1));
			 inputNeurons[i]->dendrites[0]->dendriteTo = inputNeurons[i];
			 inputNeurons[i]->dendrites[0]->dendriteFrom = outputNeurons[i];
			 inputNeurons[i]->dendrites[0]->synapses = 1;
			 //inputNeurons[i]->axons.push_back(new Dendrite());
			 //inputNeurons[i]->axons[0]->dendriteTo = outputNeurons[i];
			 //inputNeurons[i]->axons[0]->dendriteFrom = inputNeurons[i];
			 //inputNeurons[i]->axons[0]->synapses = 1;
			 //outputNeurons[i]->axons.resize(1);
			 //outputNeurons[i]->axons[0].push_back(new Dendrite());
			 //outputNeurons[i]->axons[0][0]->dendriteFrom = outputNeurons[i];
			 //outputNeurons[i]->axons[0][0]->dendriteTo = inputNeurons[i];
			 //outputNeurons[i]->axons[0][0]->synapses = 1;
			 //outputNeurons[i]->axons[0][0]->self=0;
			 outputNeurons[i]->dendrites.push_back(new Dendrite());
			 outputNeurons[i]->dendrites[0]->dendriteTo = outputNeurons[i];
			 outputNeurons[i]->dendrites[0]->synapses = 1;
			 outputNeurons[i]->dendrites[0]->activationDelay = 0;

			 //outputNeurons[i]->dendrites[1]->inhibitory = true;

			 AnsiString captionID = char(i);
			 outputNeurons[i]->outputData = char(i);
			 captionID +=  " (" +  inputNeurons[i]->id + ")";
			 inputNeurons[i]->debugCallingNode = SDIAppForm->addLink(captionID);
			// *inputNeurons = new Neuron (queue);
		}


	}
	void input (int c) {
		outputNeurons[c]->lastfired = stepCounter;
		//aqueue->schedActivation( inputNeurons[c]->dendrites[0],0);
		inputNeurons[c]->dendrites[0]->stimulate();
		//inputNeurons[c]->checkActivation();
	}
};
*/

} //Odin
