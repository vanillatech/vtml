#pragma once

namespace Odin
{

class Neuron;

class Dendrite()
{
	public:
		explicit Dendrite(float a_initialWeight);

		void changeWeights();
		void stimulate();
		
		int& synapses() {
			return m_synapses;
		}

		Neuron& from() {
			return *m_from;
		}

		Neuron& to() {
			return *m_to;
		}

	private:
		Neuron* m_from;
		Neuron* m_to;
		int m_synapses;
		int m_lastUsed;
		//bool inhibitory;
		int m_activationDelay;
		float m_weight;
};

/*
class Dendrite {
	public:
	ActivationQueue *aqueuelocal;
	Neuron *dendriteFrom;
	Neuron *dendriteTo;
	int synapses;
	int lastUsed;
	//bool inhibitory;
	int activationDelay;
	float weight;
	Dendrite(void);
	Dendrite(int);
	void changeWeights (void);
	void stimulate (void);
};
*/

} //Odin
