#pragma once
#include <queue>

namespace Odin
{

class Dendrite;
class Sense;

class ActivationQueue
{
	public:
		explicit ActivationQueue(Sense& a_sense) :
			m_sense(s_sense)
		{}
		
		void schedActivation(
			Dendrite* a_dendrite, int a_delay, double a_actVal = 1.0
		);

		void activate();
		
		bool isEmpty() {
			return m_queue.empty();
		}

	private:
		struct Item
		{
			Dendrite& dendrite;
			double actVal;
			int pos;
			
			bool retMode() const {
				return (pos != 0);
			}

			bool operator<(const Item& r) {
				if (retMode()) {
					return pos > r.pos;
				}
				return pos < r.pos;
			}

			Item(Dendrite& a_dendrite, double a_actVal, int a_pos) :
				dendrite(a_dendrite),
				actVal(a_actVal),
				pos(a_pos)
			{}
		};

		typedef std::priority_queue<Item> TQueue;

		TQueue m_queue;
		Sense& m_sense;
};

/*

class Aqueue {
	private:
	int pos;
	double actVal;
	Dendrite* dendrite;
	public:
	Aqueue(int queuePos, Dendrite* dendrite) {
		pos = queuePos;
		dendrite = dendrite;
	}
	Aqueue(double aVal, Dendrite* dendrite) {
		actVal = aVal;
		dendrite = dendrite;
	}
	Aqueue(int queuePos, Dendrite* dendrite,double aVal) {
		actVal = aVal;
		dendrite = dendrite;
		pos = queuePos;
	}
	Dendrite* getDendrite() const {
		return dendrite;
	}
	bool retMode () const {
		if (pos != 0) return true;
		else return false;
	}
	double getPos() const {
		if (retMode()) return pos;
		else return actVal;
	}
	double getAct() const {
		return actVal;
	}
};

class ActivationQueue {
	private:
	priority_queue<Aqueue> q;
	Dendrite *queue[queueMax];
	public:
	ActivationQueue (void) {
	}
	void schedActivation (Dendrite* , int);
	void schedActivation (Dendrite* , int, double);

	void activate (void);
	bool isEmpty (void);

};

*/

} //Odin
