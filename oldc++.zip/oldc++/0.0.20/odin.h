
const int queueMax = 20;
class Neuron;
class Dendrite;
class ActivationQueue;
class Sense;

class Dendrite {
	public:
	Neuron *dendriteFrom;
	Neuron *dendriteTo;
	int synapses;
};
class ActivationQueue {
	private:
	int counter;
	Dendrite *queue[queueMax];
	public:
	ActivationQueue (void) {
		this->counter = 0;
    }
	void schedActivation (Dendrite* dendrite) {
		this->queue[this->counter] = new Dendrite;
		this->queue[this->counter][sizeof(this->queue[this->counter])-1] = *dendrite;
	}
	void activate (void);

};

class RecoveryQueue {
	private:
	int counter;
	Neuron *queue[queueMax];
	public:
	RecoveryQueue (void) {
		this->counter = 0;
	}
	void insert(Neuron *neuron) {
		this->queue[this->counter]  = new Neuron;
		this->queue[this->counter][sizeof(this->queue[this->counter])-1] = *neuron;
	}
};

class Neuron {
	public:
	  ActivationQueue* activationQueue;
	  Dendrite *dendrites;
	  double activationVal;

	  //Constructor
	  Neuron (ActivationQueue*);
	  //Functions
	  void newLink (void) {
		  this->dendrites = new Dendrite;
	  }
	  int countSynapses (void) {
		  int countSyn = 0;
		  for (int n=0;n<sizeof(this->dendrites);n++) {
			countSyn += this->dendrites->synapses;
		  }
		  return (countSyn);
	  }
	  void activate (double);
	  void fire (void) {
		  this->activationVal = 0;
		  if (this->dendrites) {
			  for (int n;n<sizeof(this->dendrites) ;n++ ) {
				this->activationQueue->schedActivation(&this->dendrites[n]);
			  }
		  }
	  }
	  void checkActivation (void) {
		  if (this->activationVal >= 1) {
			  this->fire();
		  }
	  }
};

class Sense {
	private:
	Neuron *inputNeurons[256];
	public:
	Sense (ActivationQueue *queue) {
		//inputNeurons = new (Neuron*)[256];
		//inputNeurons = new Neuron(&queue)[256];
		for ( int  i = 0 ; i < 256 ; i++ )
			 this->inputNeurons[i] = new  Neuron (queue);
			//*inputNeurons = new Neuron (queue);

		
	}
	void input (int c) {
		this->inputNeurons[c]->activate(1);
    }
};


void ActivationQueue::activate (void) {
	this->counter++;
	if (this->counter>=queueMax) {  this->counter = 0; }
	int elements = 0;
	if (this->queue[this->counter]) {
		elements = sizeof(this->queue[this->counter]);
	}
	for (int n=0;n<elements ;n++ ) {
		double actVal = 0;
		actVal = this->queue[this->counter][n].synapses / this->queue[this->counter][n].dendriteFrom->countSynapses();
		this->queue[this->counter][n].dendriteTo->activate(actVal);
	}
	delete [] this->queue[this->counter];
}

Neuron::Neuron (ActivationQueue* queue) {
		  this->activationQueue = queue;
		  this->activationVal = 0;
		  this->dendrites = NULL;
}

void Neuron::activate(double activationValNew) {
  this->activationVal += activationValNew;
  this->checkActivation();
}
