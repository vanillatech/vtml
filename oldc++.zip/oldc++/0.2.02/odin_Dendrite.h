Dendrite::Dendrite (void){
	this->aqueuelocal = &aqueue;
};

void Dendrite::changeWeights (void) {
		this->weight = this->weight * (1 - learnRate )+    (1 - learnRate);
};

void Dendrite::stimulate (void) {
		this->aqueuelocal->schedActivation(this, this->activationDelay);

};
