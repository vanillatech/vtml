#include <queue>
#include <vector>
#include "debug.h"

using namespace std;

const int queueMax = 20;
const int recoveryTime = 1;
const float activationBias = 0.5;
const float drain = 0.9;
const float minActivation = 0.01;

int neuronCounter = 0;
int stepCounter = recoveryTime + 1;
class Neuron;
class Dendrite;
class ActivationQueue;
class Sense;
class RecoveryQueue;


class Dendrite {
	public:
	Neuron *dendriteFrom;
	Neuron *dendriteTo;
	int synapses;
	int self;
	//bool inhibitory;
	int activationDelay;
	//Dendrite(void) { this->inhibitory = false; }
};

class Aqueue {
	private:
	int pos;
	double actVal;
	Dendrite* dendrite;
	public:
	Aqueue(int queuePos, Dendrite* dendrite) {
		this->pos = queuePos;
		this->dendrite = dendrite;
	}
	Aqueue(double aVal, Dendrite* dendrite) {
		this->actVal = aVal;
		this->dendrite = dendrite;
    }
	Dendrite* getDendrite() const {
		return this->dendrite;
	}
	double getPos() const {
		if (this->pos != 0 ) return this->pos;
		else return this->actVal;
	}
};


bool operator<(const Aqueue &a, const Aqueue &b) {
	return a.getPos() > b.getPos();
}

class ActivationQueue {
	private:
	priority_queue<Aqueue> q;
	Dendrite *queue[queueMax];
	public:
	ActivationQueue (void) {
	}
	void schedActivation (Dendrite* dendrite, int aDelay) {
		this->q.push(Aqueue(aDelay+stepCounter,dendrite));
	}
	void activate (void);
	bool isEmpty (void);

};

class RecoveryQueue {
	private:
	int counter;
	int lastelement;
	int layer;
	vector <Neuron*> queue[20];
	public:
	RecoveryQueue(void) {}
	RecoveryQueue (int nLayer) {
		//this->queue.resize(queueMax);
		this->counter = 0;
		this->lastelement = 0;
		this->layer = nLayer;
	}
	int deletePattern(Neuron *, int, unsigned int, unsigned int);
	void insert(Neuron *);
	void checkNewPattern ();
	void recover(void);
	int countItems (void);
};

class Neuron {
	private:

	  void drainActivation (void);


	public:
	  //TDebug1 *debuginst;
	  TTreeNode *debugCallingNode;
	  ActivationQueue* activationQueue;
	  vector <RecoveryQueue> *recoveryQueue;
	  vector <Dendrite*> axons;
	  vector < vector <Dendrite*> > dendrites;
	  double activationVal;
	  int layer;
	  AnsiString id;
	  int lastchecked;
	  char outputData;
	  int lastfired;

	  //Constructor
	  Neuron (ActivationQueue*, vector< RecoveryQueue > * ,unsigned int);
	  //Functions
	  void newLink (Neuron *, int, unsigned int,int);
	  int countSynapses (int);
	  void activate (double);
	  void fire (void);
	  void predictNext (void);
	  void propagateDown(int);
	  int checkActivation (void);
	  void inhibit (void);
	  bool containsDendrite(Neuron *);
};

class Sense {
	private:
	ActivationQueue *aqueue;
	Neuron *inputNeurons[256];
	Neuron *outputNeurons[256];
	public:
	Sense (ActivationQueue *queue, vector< RecoveryQueue > *recQueueTemp) {
		//inputNeurons = new (Neuron*)[256];
		//inputNeurons = new Neuron(&queue)[256];
		//first check that the capacity of recQueue is sufficient
		(*recQueueTemp).reserve((*recQueueTemp).size()+3);
		this->aqueue = queue;
		for ( int  i = 0 ; i < 256 ; i++ ) {
			 this->inputNeurons[i] = new  Neuron (aqueue,recQueueTemp,0);
			 this->outputNeurons[i] = new  Neuron (aqueue,recQueueTemp,0);
			 this->inputNeurons[i]->dendrites.resize(1);
			 this->inputNeurons[i]->dendrites[0].push_back(new Dendrite());
			 this->inputNeurons[i]->dendrites[0][0]->dendriteTo = this->inputNeurons[i];
			 this->inputNeurons[i]->dendrites[0][0]->dendriteFrom = this->outputNeurons[i];
			 this->inputNeurons[i]->dendrites[0][0]->synapses = 1;
			 this->inputNeurons[i]->dendrites[0][0]->self = 0;
			 /*this->inputNeurons[i]->axons.push_back(new Dendrite());
			 this->inputNeurons[i]->axons[0]->dendriteTo = this->outputNeurons[i];
			 this->inputNeurons[i]->axons[0]->dendriteFrom = this->inputNeurons[i];
			 this->inputNeurons[i]->axons[0]->synapses = 1;*/
			 /*this->outputNeurons[i]->axons.resize(1);
			 this->outputNeurons[i]->axons[0].push_back(new Dendrite());
			 this->outputNeurons[i]->axons[0][0]->dendriteFrom = this->outputNeurons[i];
			 this->outputNeurons[i]->axons[0][0]->dendriteTo = this->inputNeurons[i];
			 this->outputNeurons[i]->axons[0][0]->synapses = 1;
			 this->outputNeurons[i]->axons[0][0]->self=0;*/
			 this->outputNeurons[i]->dendrites.resize(1);
			 this->outputNeurons[i]->dendrites[0].push_back(new Dendrite());
			 this->outputNeurons[i]->dendrites[0][0]->dendriteTo = this->outputNeurons[i];
			 this->outputNeurons[i]->dendrites[0][0]->synapses = 1;
			 this->outputNeurons[i]->dendrites[0][0]->self = 0;
			 this->outputNeurons[i]->dendrites[0][0]->activationDelay = 0;

			 //this->outputNeurons[i]->dendrites[1]->inhibitory = true;

			 AnsiString captionID = char(i);
			 outputNeurons[i]->outputData = char(i);
			 captionID +=  " (" +  inputNeurons[i]->id + ")";
			 inputNeurons[i]->debugCallingNode = SDIAppForm->addLink(captionID);
			//*inputNeurons = new Neuron (queue);
		}


	}
	void input (int c) {
		this->outputNeurons[c]->lastfired = stepCounter;
		this->aqueue->schedActivation( this->inputNeurons[c]->dendrites[0][0],0);

		//this->inputNeurons[c]->checkActivation();
	}
};

vector <RecoveryQueue> recQueue;
//RecoveryQueue *recQueue = new RecoveryQueue[1];
ActivationQueue aqueue;
Sense *readSense;
Neuron *lastFiredNeuron;



//**********
//Member functions ActivationQueue
//**********



void ActivationQueue::activate (void) {
	stepCounter++;
	Debug1->ListBox1->Items->Insert(0,AnsiString("----------- ") + AnsiString(stepCounter) + AnsiString("------------"));
	priority_queue <Aqueue> qtemp;
	//first activate subsequent neurons
	while ((!this->q.empty()) && this->q.top().getPos() <= stepCounter) {
		Dendrite *d;
		d = this->q.top().getDendrite();
		double actVal = 0;
		actVal = d->synapses / double(d->dendriteTo->countSynapses(d->self));
		//actVal = 1;
		if (actVal > minActivation && (d->dendriteTo->lastfired < (stepCounter - recoveryTime))) {
			d->dendriteTo->activate(actVal);
			qtemp.push(Aqueue(d->dendriteTo->activationVal,d));
		}
		this->q.pop();
	}
	//now check if the activation leads to depolarization of the subsequent neuron
	while (!qtemp.empty()) {
		Dendrite *d;
		d = qtemp.top().getDendrite();

		if (d->dendriteTo->checkActivation() == 1) {
			d->synapses++; //hebbian learning rule - synaptic plasticity
        }
		qtemp.pop();
	}
}

bool ActivationQueue::isEmpty(void) {
    return this->q.empty();
}

//**********
//Member functions Neuron
//**********


Neuron::Neuron (ActivationQueue* queue, vector< RecoveryQueue > *recQueueTemp, unsigned int nLayer) {
		  this->activationQueue = queue;
		  this->recoveryQueue = recQueueTemp;
		  /*if (this->recoveryQueue->capacity() == 0) {
			this->recoveryQueue->reserve(1);
			(*recoveryQueue)[0] = RecoveryQueue();
		  } */
		  if ((*recoveryQueue).size() ==nLayer) {
			//this->recoveryQueue->resize(this->recoveryQueue->size()+1);
			(*recoveryQueue).push_back(RecoveryQueue(nLayer));
			//this->recoveryQueue->at(nLayer) = new RecoveryQueue;
		  }
		  this->activationVal = 0;
		  this->lastchecked = recoveryTime;
		  this->lastfired = 0;
		  this->layer = nLayer;
		  this->id = neuronCounter++;
		  this->outputData = 0;
}

void Neuron::newLink (Neuron *toNeuron, int ndelay, unsigned int dendriteNum,int countTotal) {

		  int g = axons.size();
		  Dendrite *tempDend = new Dendrite();
		  axons.push_back(tempDend);
		  (*axons[g]).dendriteFrom = this;
		  (*axons[g]).dendriteTo = toNeuron;
		  (*axons[g]).synapses = 1;
		  (*axons[g]).self = dendriteNum;
		  (*axons[g]).activationDelay = ndelay;
		  if (toNeuron->dendrites.size() < dendriteNum + 1) {
			toNeuron->dendrites.resize(dendriteNum+1);
		  }
		  toNeuron->dendrites[dendriteNum].push_back(&(*axons[g]));

		  AnsiString captionID = toNeuron->id;
		  captionID += " layer: ";
		  captionID += toNeuron->layer;
		  toNeuron->debugCallingNode = SDIAppForm->addLink(captionID,this->debugCallingNode);
		  Debug1->refreshTT();

		  Debug1->ListBox1->Items->Insert(0,"NewLink: " + id + " to " + toNeuron->id);
}

int Neuron::countSynapses (int dendriteNum) {
		  int countSyn = 0;
		  for (unsigned int n=0;n<dendrites[dendriteNum].size();n++) {
			countSyn += (*dendrites[dendriteNum][n]).synapses;
		  }
		  return (countSyn);
}

void Neuron::activate(double activationValNew) {
  this->drainActivation();
  if (this->lastfired < stepCounter - recoveryTime) {
	this->activationVal += activationValNew;
	Debug1->ListBox1->Items->Insert(0,"Activate Neuron: " + id + " (" + AnsiString (activationValNew)+") " );
	//this->checkActivation();
  };
}

void Neuron::drainActivation(void) {
  for (int n=0;n<50 && n<(stepCounter-lastchecked)&&lastchecked>0 ;n++ ) {
			this->activationVal *= drain;
  }
  lastchecked = stepCounter;
}

void Neuron::fire (void) {
          if (this->outputData != 0) {
			SDIAppForm->Label1->Caption = SDIAppForm->Label1->Caption + this->outputData;
		  }
		  Debug1->ListBox1->Items->Insert(0,"Neuron fired: " + id );
		  this->activationVal = 0;
		  this->lastfired = stepCounter;
		  //WTA: Winner Takes All - inhibit
		  for (unsigned int n=0;n<dendrites.size();n++) {
			for (unsigned int m=0;m<dendrites[n].size() ;m++ ) {
				if ((*dendrites[n][m]).dendriteFrom != 0)
					(*dendrites[n][m]).dendriteFrom->inhibit();
			}
		  }
		  //activate parent neurons
		  for (unsigned int n=0;n<axons.size();n++ ) {
					Debug1->ListBox1->Items->Insert(0,"Schedule Activation: " + axons[n]->dendriteTo->id + " in: " + AnsiString((*axons[n]).activationDelay) );
					this->activationQueue->schedActivation(&(*axons[n]),(*axons[n]).activationDelay);
		  }
		  //only insert into rec.queue when fired twice within recoveryTime
		  //--EXPERIMENTAL--
		  //if (this->lastfired + recoveryTime > stepCounter) {

          //delete fired pattern from recoveryqueue
		  if (this->layer >= 1) {
				for (unsigned int n = 0;n<this->dendrites.size() ;n++ ) {
					  (*recoveryQueue)[this->layer - 1].deletePattern(this,n,0,0);
				}
		  }
		  (*recoveryQueue)[this->layer].insert(this);
		  //this->predictNext();
		  /*if (this->layer > 0) {
			  this->propagateDown(0);
		  } */
		  /*0.0.37
		  if (lastFiredNeuron != 0) {
			if (!this->containsDendrite(lastFiredNeuron)) {
				lastFiredNeuron->newLink(this,1,lastFiredNeuron->dendrites.size(),1);
			}
		  }*/
		  lastFiredNeuron = this;

		  //} *
}

void Neuron::predictNext(void) {
	//0.0.50: select strongest axon
	Dendrite *strongestAxon = NULL;
	for (unsigned int g=0;g<this->axons.size() ;g++ ) {
		if (g==0 && this->axons[0] != 0) strongestAxon = this->axons[0];
		if (this->axons[g] != 0) {
			AnsiString d = this->axons[g]->dendriteFrom->id;
			AnsiString e = this->axons[g]->dendriteTo->id;
			//a is actually wrong! will only cause to count the lastfired axon to be used for calculation.
			double a = strongestAxon->synapses / double(strongestAxon->dendriteTo->countSynapses(strongestAxon->self));
			double b = this->axons[g]->synapses / double(this->axons[g]->dendriteTo->countSynapses(this->axons[g]->self));
			if (a < b) {
				strongestAxon = this->axons[g];
			}
		}
	}
	//--0.0.50

	if (strongestAxon) {
		if (strongestAxon->dendriteTo != 0) {
		int m = strongestAxon->self;
			for (unsigned int n=0;n<strongestAxon->dendriteTo->dendrites[m].size() ;n++ ) {
				if (strongestAxon->dendriteTo->dendrites[m][n]->dendriteFrom != 0) {
						int timeOffset = strongestAxon->activationDelay;
						timeOffset -= strongestAxon->dendriteTo->dendrites[m][n]->activationDelay;
						strongestAxon->dendriteTo->dendrites[m][n]->dendriteFrom->propagateDown(timeOffset);
				}
				/*if (this->axons[0]->dendriteTo->dendrites[m][n] == this->axons[0]) {
					if (this->axons[0]->dendriteTo->dendrites[m][n+1]->dendriteFrom != 0) {
						this->axons[0]->dendriteTo->dendrites[n+1]->dendriteFrom->propagateDown();
					}
				}*/

			}
		}
	}
}

void Neuron::propagateDown(int timeOffset) {
	if (this->outputData != 0 && timeOffset >= 0) {
			this->activationQueue->schedActivation(&(*dendrites[0][0]), timeOffset);
			//SDIAppForm->Label1->Caption = SDIAppForm->Label1->Caption + this->outputData;
			//this->fire();
	}
	for (unsigned int m=0; m<this->dendrites.size() ; m++) {
	for (unsigned int n=0; n<this->dendrites[m].size() ; n++) {
		if (this->dendrites[m][n]->dendriteFrom != 0) {
			int timeOffsetTmp = timeOffset - this->dendrites[m][n]->activationDelay;
			this->dendrites[m][n]->dendriteFrom->propagateDown(timeOffsetTmp);
		}
	}
	}
}

int Neuron::checkActivation (void) {
	this->drainActivation();
	if (this->activationVal >= activationBias) {
			  this->fire();
			  return(1);
	}
	if (this->lastfired == stepCounter) {
        return (1);
	}
	return(0);
}

void Neuron::inhibit (void) {
		  //inhibits current neuron and all successors with the value that had
		  //been scheduled for activation of the successor before.
		  Debug1->ListBox1->Items->Insert(0,"Inhibit: " + id );

		  this->lastfired = stepCounter-1; //sets recoveryTime
		  this->activationVal = 0;
		  for (unsigned int n=0;n<axons.size();n++ ) {
				double inval = double((*axons[n]).synapses) / (*axons[n]).dendriteTo->countSynapses((*axons[n]).self);
				(*axons[n]).dendriteTo->activationVal -= inval;
		  }
}

bool Neuron::containsDendrite(Neuron *compareNeuron) {
	for (unsigned int n = 0;n< this->dendrites.size() ;n++ ) {
		for (unsigned int m=0;m< this->dendrites[n].size() ;m++ ) {
			if (this->dendrites[n][m]->dendriteFrom == compareNeuron) {
				return (true);
			}
		}
	}
	return (false);
}

//**********
//Member functions RecoveryQueue
//**********

int RecoveryQueue::deletePattern(Neuron *neuron, int dendritePos, unsigned int pos, unsigned int forderOld) {
   int forderNew = 0;
   int retVal = 0;
   if (pos == neuron->dendrites[dendritePos].size()) {return(1);}
   if (pos > 0) {
	   int delay = neuron->dendrites[dendritePos][pos]->activationDelay - neuron->dendrites[dendritePos][pos - 1]->activationDelay;
	   forderNew = forderOld - delay;
	   if (forderNew < 0) forderNew+=queueMax;
	   for (int n = 0;n<queueMax && !queue[forderNew].empty();n++) {
		if (neuron->dendrites[dendritePos][pos]->dendriteFrom == queue[forderNew][n]) {
		  retVal = deletePattern(neuron,dendritePos,pos+1,forderNew);
		  if (retVal == 1) {
			Debug1->ListBox1->Items->Insert(0,"Delete from Rq: " + queue[forderNew][n]->id);
			queue[forderNew].erase(queue[forderNew].begin()+n);
          	return(1);
		  }

		}
	   }
   } else {
	for (int m=0;m<queueMax ;m++ ) {
	for (unsigned int n=0;n < queue[m].size() ;n++ ) {
			if (neuron->dendrites[dendritePos][pos]->dendriteFrom == queue[m][n] ) {
				retVal = deletePattern(neuron,dendritePos,pos+1,m);
				if (retVal == 1) {
                   Debug1->ListBox1->Items->Insert(0,"Delete from Rq: " + queue[m][n]->id);
				   queue[m].erase(queue[m].begin()+n);
				   return(1);
				}
			}
	}}
   }
   return(retVal);
}


void RecoveryQueue::insert(Neuron *neuron) {
		//insert actual neuron
		this->queue[this->counter].push_back(neuron);
}

void RecoveryQueue::checkNewPattern() {
	//Associate everything in recQueue with a new neuron
		if (this->queue[this->lastelement].empty() && this->countItems() > 1) { //experimental
			//only insert if there has nothing been fired last time.
			Neuron *newNeuron = new Neuron(&aqueue,&recQueue,this->layer + 1);
			int dendritePos = newNeuron->dendrites.size();
			int c = this->counter - 1;
			for (int n=0;n<queueMax ;n++ ) {

				if (c<0) { c = queueMax - 1; }
				unsigned int countTotal = queue[c].size();
				for (unsigned int m=0;m < countTotal ;m++ ) {
						queue[c][m]->newLink(newNeuron,n,dendritePos,countTotal);
				}

				c--;
			}
			for (unsigned int n = 0;n < newNeuron->dendrites.size() && deletePattern(newNeuron,n,0,0)!=1;n++);
			lastFiredNeuron = newNeuron;
		}

		if (recQueue.capacity() < recQueue.size() + 3) {
			recQueue.reserve(recQueue.size()+3);
		}
}

void RecoveryQueue::recover(void) {
		this->lastelement = this->counter;
		this->counter++;
		if (this->counter>=queueMax) {  this->counter = 0; }
		this->queue[this->counter].clear();
		this->checkNewPattern();
}

int RecoveryQueue::countItems() {
	int cItems = 0;
	for (int n=0;n<queueMax ;n++ ) {
		cItems += queue[n].size();
	}
	return (cItems);
}


