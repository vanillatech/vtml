

//**********
//Member functions RecoveryQueue
//**********

int RecoveryQueue::deletePattern(Neuron *neuron, unsigned int pos, unsigned int forderOld) {
   int forderNew = 0;
   int retVal = 0;
   if (pos == neuron->dendrites.size()) {return(1);}
   if (pos > 0) {
	   int delay = neuron->dendrites[pos]->activationDelay - neuron->dendrites[pos - 1]->activationDelay;
	   forderNew = forderOld - delay;
	   if (forderNew < 0) forderNew+=queueMax;
	   for (int n = 0;n<queueMax && !queue[forderNew].empty();n++) {
		if (neuron->dendrites[pos]->dendriteFrom == queue[forderNew][n]) {
		  retVal = deletePattern(neuron,pos+1,forderNew);
		  if (retVal == 1) {
			Debug1->ListBox1->Items->Insert(0,"Delete from Rq: " + queue[forderNew][n]->id);
			queue[forderNew].erase(queue[forderNew].begin()+n);
			return(1);
		  }

		}
	   }
   } else {
	for (int m=0;m<queueMax ;m++ ) {
	for (unsigned int n=0;n < queue[m].size() ;n++ ) {
			if (neuron->dendrites[pos]->dendriteFrom == queue[m][n] ) {
				retVal = deletePattern(neuron,pos+1,m);
				if (retVal == 1) {
                   Debug1->ListBox1->Items->Insert(0,"Delete from Rq: " + queue[m][n]->id);
				   queue[m].erase(queue[m].begin()+n);
				   return(1);
				}
			}
	}}
   }
   return(retVal);
}


void RecoveryQueue::insert(Neuron *neuron) {
        //if a new neuron is inserted into the queue it is not idle anymore.
		if (recQueueIdle >= this->layer) recQueueIdle = this->layer - 1;
		if (stepLastElement != stepCounter) {
			this->recover();
			stepLastElement = stepCounter;
		}
		//insert actual neuron
		this->queue[this->counter].push_back(neuron);
}

void RecoveryQueue::checkNewPattern() {
	//Associate everything in recQueue with a new neuron
		//only check for new pattern if nothing has been fired on all of the layers below current layer (0.0.61)
		if (this->queue[this->lastelement].empty() && recQueueIdle == (this->layer - 1)) {
			recQueueIdle = this->layer;
		}
		if ( recQueueIdle == this->layer && this->countItems() > 1) { //experimental
			Neuron *newNeuron = new Neuron(&aqueue,&recQueue,this->layer + 1);
			int c = this->counter - 1;
			for (int n=0;n<queueMax ;n++ ) {

				if (c<0) { c = queueMax - 1; }
				unsigned int countTotal = queue[c].size();
				for (unsigned int m=0;m < countTotal ;m++ ) {
						queue[c][m]->newLink(newNeuron,n,countTotal);
				}

				c--;
			}
			deletePattern(newNeuron,0,0);
			newNeuron->fire();
			//lastFiredNeuron = newNeuron;
		}

		if (recQueue.capacity() < recQueue.size() + 3) {
			recQueue.reserve(recQueue.size()+3);
		}
}

void RecoveryQueue::recover(void) {
		this->lastelement = this->counter;
		this->counter++;
		if (this->counter>=queueMax) {  this->counter = 0; }
		this->queue[this->counter].clear();
		this->checkNewPattern();
}

int RecoveryQueue::countItems() {
	int cItems = 0;
	for (int n=0;n<queueMax ;n++ ) {
		cItems += queue[n].size();
	}
	return (cItems);
}

