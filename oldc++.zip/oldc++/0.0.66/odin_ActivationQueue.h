//**********
//Member functions ActivationQueue
//**********



void ActivationQueue::activate (void) {
	stepCounter++;
	Debug1->ListBox1->Items->Insert(0,AnsiString("----------- ") + AnsiString(stepCounter) + AnsiString("------------"));
	priority_queue <Aqueue> qtemp;
	//first activate subsequent neurons
	while ((!this->q.empty()) && this->q.top().getPos() <= stepCounter) {
		Dendrite *d;
		d = this->q.top().getDendrite();
		double actVal = 0;
		int cs = d->dendriteTo->countSynapses();
		if (cs > 0) actVal = d->synapses / double(d->dendriteTo->countSynapses());
		else actVal = 0;
		//actVal = 1;
		if (actVal > minActivation && (d->dendriteTo->lastfired < (stepCounter - recoveryTime))) {
			d->dendriteTo->activate(actVal);
			qtemp.push(Aqueue(d->dendriteTo->activationVal,d));
		}
		this->q.pop();
	}
	//now check if the activation leads to depolarization of the subsequent neuron
	while (!qtemp.empty()) {
		Dendrite *d;
		d = qtemp.top().getDendrite();

		if (d->dendriteTo->checkActivation() == 1) {
			d->synapses += 2; //hebbian learning rule - synaptic plasticity
		}
		qtemp.pop();
	}
}

bool ActivationQueue::isEmpty(void) {
    return this->q.empty();
}
