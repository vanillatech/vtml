#pragma once

namespace Odin
{

struct Dendrite1Data
{
	int synapses;
	TTime lastUsed;
	TTime activationDelay;
	float weight;
};


} //Odin
